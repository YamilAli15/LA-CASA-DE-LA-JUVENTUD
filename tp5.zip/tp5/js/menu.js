// =====================================================
// ELEMENTOS DEL DOM
// =====================================================
const btnTalleres = document.getElementById("btn-talleres");
const menuTalleres = document.getElementById("menu-talleres-completo");
const btnCerrarMenu = document.getElementById("cerrar-menu");
const grid = document.getElementById("grid-talleres");
const btnConsultas = document.getElementById("btn-consultas");

// =====================================================
// REDIRECCIÓN DEL ÍCONO DEL MENÚ (LOGIN / LOGO)
// =====================================================
document.querySelector(".menu-icon").addEventListener("click", () => {
    window.location.href = "menu.html"; // Cambiar ruta si es necesario
});

// =====================================================
// CARGAR ÍTEMS DEL MENÚ DINÁMICAMENTE
// =====================================================
if (grid) {
    const iconosMenu = [
        "imagenes/iconos/ajedrez-01.png",
        "imagenes/iconos/arte-01.png",
        "imagenes/iconos/carpinteria-01.png",
        "imagenes/iconos/ceramica-01.png",
        "imagenes/iconos/deporte-01.png",
        "imagenes/iconos/herreria-01.png",
        "imagenes/iconos/hilorama-01.png",
        "imagenes/iconos/huerta-01.png",
        "imagenes/iconos/informatica-01.png",
        "imagenes/iconos/manualidades-01.png",
        "imagenes/iconos/musica-01.png",
        "imagenes/iconos/panaderia-01.png",
        "imagenes/iconos/ping_pong-01.png"
    ];

    const nombresMenu = [
        "Ajedrez", "Arte", "Carpintería", "Cerámica", "Deporte",
        "Herrería", "Hilorama", "Huerta", "Informática",
        "Manualidades", "Música", "Panadería", "Ping Pong"
    ];

    const urlsMenu = [
        "talleres/ajedrez.html",
        "talleres/arte.html",
        "talleres/carpinteria.html",
        "talleres/ceramica.html",
        "talleres/deporte.html",
        "talleres/herreria.html",
        "talleres/hilorama.html",
        "talleres/huerta.html",
        "talleres/informatica.html",
        "talleres/manualidades.html",
        "talleres/musica.html",
        "talleres/panaderia.html",
        "talleres/pingpong.html"
    ];

    grid.innerHTML = iconosMenu.map((src, i) => `
        <div class="taller-item" onclick="window.location.href='${urlsMenu[i]}'">
            <div class="icono" style="background-image: url('${src}')"></div>
            <p>${nombresMenu[i]}</p>
        </div>
    `).join("");
}

// =====================================================
// ABRIR MENÚ DE TALLERES
// =====================================================
if (btnTalleres) {
    btnTalleres.addEventListener("click", () => {
        menuTalleres.classList.remove("animar-subir");
        menuTalleres.classList.add("animar-bajar");

        menuTalleres.style.display = "flex";
        btnCerrarMenu.classList.remove("oculto");
        document.body.style.overflow = "hidden";
    });
}

// =====================================================
// CERRAR MENÚ DE TALLERES
// =====================================================
if (btnCerrarMenu) {
    btnCerrarMenu.addEventListener("click", () => {
        menuTalleres.classList.remove("animar-bajar");
        menuTalleres.classList.add("animar-subir");

        setTimeout(() => {
            menuTalleres.style.display = "none";
        }, 300);

        btnCerrarMenu.classList.add("oculto");
        document.body.style.overflow = "auto";
    });
}

// =====================================================
// BOTÓN CONSULTAS
// =====================================================
if (btnConsultas) {
    btnConsultas.addEventListener("click", () => {
        window.location.href = "Comunicate.html";
    });
}

// =====================================================
// FORMULARIO – Mensaje + sonido sin recargar
// =====================================================
const formulario = document.querySelector(".formulario-contacto");
const mensajeExito = document.getElementById("mensaje-exito");

// 🔊 SONIDO DE ÉXITO (PONÉ TU ARCHIVO AQUÍ)
const sonidoExito = new Audio("sonidos/exito.mp3");

formulario.addEventListener("submit", function(event) {
    event.preventDefault();  // ❌ Evita recargar

    // Reproducir sonido
    sonidoExito.currentTime = 0;
    sonidoExito.play();

    // Mostrar cartel
    mensajeExito.classList.remove("oculto");
    mensajeExito.classList.add("mostrar");

    // Limpiar formulario
    formulario.reset();

    // Ocultar después de 3 segundos
    setTimeout(() => {
        mensajeExito.classList.remove("mostrar");
        setTimeout(() => mensajeExito.classList.add("oculto"), 400);
    }, 2500);
});
