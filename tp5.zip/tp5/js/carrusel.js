/* ==========================================
   CARRUSEL DE LA SECCIÓN TALLER CON INFO
========================================== */
const carruselImg = document.getElementById("carrusel-img");
const btnIzq = document.getElementById("flecha-izq");
const btnDer = document.getElementById("flecha-der");
const tituloTaller = document.getElementById("taller-titulo");
const descTaller = document.getElementById("taller-descripcion");
const btnVerTaller = document.getElementById("btn-ver-taller");

/* Datos de los talleres */
const talleres = [
    {nombre: "Ajedrez", descripcion: "Aprendé estrategias y técnicas para mejorar tu juego de ajedrez y participar en torneos locales. Ideal para todas las edades y niveles, fomentando concentración, pensamiento crítico y diversión.", url: "talleres/ajedrez.html", imagen: "imagenes/iconos/ajedrez-01.png"},
    {nombre: "Arte", descripcion: "Explorá tu creatividad con pintura, dibujo y técnicas mixtas. Compartí tus obras y aprendé de otros participantes en un ambiente artístico y motivador.", url: "talleres/arte.html", imagen: "imagenes/iconos/arte-01.png"},
    {nombre: "Carpintería", descripcion: "Aprendé a construir muebles y objetos de madera con herramientas básicas. Fomentamos la creatividad y la seguridad en el manejo de herramientas.", url: "talleres/carpinteria.html", imagen: "imagenes/iconos/carpinteria-01.png"},
    {nombre: "Cerámica", descripcion: "Descubrí técnicas de modelado, esmaltado y decoración. Ideal para quienes quieren expresarse con sus manos y crear piezas únicas.", url: "talleres/ceramica.html", imagen: "imagenes/iconos/ceramica-01.png"},
    {nombre: "Deporte", descripcion: "Participá de actividades físicas y deportes recreativos para todas las edades. Mejorá tu coordinación, trabajo en equipo y hábitos saludables mientras te divertís.", url: "talleres/deporte.html", imagen: "imagenes/iconos/deporte-01.png"},
    {nombre: "Herrería", descripcion: "Aprendé a trabajar el hierro creando herramientas y piezas decorativas. Fomentamos la creatividad y el respeto por la seguridad en el taller.", url: "talleres/herreria.html", imagen: "imagenes/iconos/herreria-01.png"},
    {nombre: "Hilorama", descripcion: "Desarrollá destreza manual y creatividad con hilorama y tejidos. Aprendé técnicas paso a paso para crear obras únicas.", url: "talleres/hilorama.html", imagen: "imagenes/iconos/hilorama-01.png"},
    {nombre: "Huerta", descripcion: "Aprendé a cultivar y mantener un huerto urbano de forma sostenible. Ideal para quienes quieren conectarse con la naturaleza y la alimentación saludable.", url: "talleres/huerta.html", imagen: "imagenes/iconos/huerta-01.png"},
    {nombre: "Informática", descripcion: "Introducción a computación, software y programación básica. Desarrollá habilidades digitales y aprendé a crear tus propios proyectos.", url: "talleres/informatica.html", imagen: "imagenes/iconos/informatica-01.png"},
    {nombre: "Manualidades", descripcion: "Proyectos de manualidades con distintos materiales y técnicas. Ideal para desarrollar creatividad, paciencia y atención al detalle.", url: "talleres/manualidades.html", imagen: "imagenes/iconos/manualidades-01.png"},
    {nombre: "Música", descripcion: "Iniciate en la práctica de instrumentos musicales y teoría básica. Desarrollá oído musical, ritmo y expresión artística.", url: "talleres/musica.html", imagen: "imagenes/iconos/musica-01.png"},
    {nombre: "Panadería", descripcion: "Aprendé técnicas de panadería y repostería casera. Desde pan simple hasta recetas creativas y dulces, fomentando la pasión por la cocina.", url: "talleres/panaderia.html", imagen: "imagenes/iconos/panaderia-01.png"},
    {nombre: "Ping Pong", descripcion: "Torneos y técnicas para mejorar tu juego de ping pong. Ideal para todas las edades, promoviendo concentración, reflejos y diversión.", url: "talleres/pingpong.html", imagen: "imagenes/iconos/ping_pong-01.png"}
];

/* Estado actual del carrusel */
let indiceActual = 0;

/* Función para actualizar carrusel e info */
function mostrarCarrusel() {
    const taller = talleres[indiceActual];
    carruselImg.style.backgroundImage = `url('${taller.imagen}')`;
    tituloTaller.textContent = taller.nombre;
    descTaller.textContent = taller.descripcion;
    btnVerTaller.onclick = () => window.location.href = taller.url;
}

/* Navegación */
btnIzq.addEventListener("click", () => {
    indiceActual = (indiceActual - 1 + talleres.length) % talleres.length;
    mostrarCarrusel();
});

btnDer.addEventListener("click", () => {
    indiceActual = (indiceActual + 1) % talleres.length;
    mostrarCarrusel();
});

/* Inicializar */
mostrarCarrusel();
